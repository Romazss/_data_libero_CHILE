# Biblioteca de Datos Abiertos de Chile (Scaffold)

Estructura mínima del repositorio. Rellena cada carpeta según tu flujo de trabajo:

- `data_sources/` → configuración (`config/sources.yaml`) y scripts de ingesta.
- `web_app/` → frontend y backend del portal.
- `libraries/` → paquetes en R y Python.
- `docs/` → documentación y planes.

> Generado automáticamente el 2025-08-27 22:03.
